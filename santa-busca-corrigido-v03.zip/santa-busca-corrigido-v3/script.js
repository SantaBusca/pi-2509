"use strict";

const state = {
    produtos: [],
    categorias: [],
    coordsMap: {},
    selectedCategory: null,
    filtrosOrdenacao: {
        preco: true,
        distancia: true
    }
};

const $ = (id) => document.getElementById(id);
const grid = $("grid");
const search = $("search");
const count = $("count");
const statusDiv = $("status");
const categoryFilters = $("categoryFilters");
const userLatInput = $("userLat");
const userLonInput = $("userLon");
const btnGeoHeader = $("btnGeoHeader");
const userPoints = $("userPoints");

let reportContext = null;

const escapeHTML = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (character) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[character]));

const formatPrice = (value) =>
    new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL"
    }).format(Number(value));

const debounce = (fn, ms = 160) => {
    let timer;

    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), ms);
    };
};


function parseDecimalInput(value, allowNegative = false) {
    const sanitized = SantaBuscaStorage.sanitizeDecimal(
        value,
        allowNegative
    );
    return sanitized === "" || sanitized === "-" || sanitized === "."
        ? NaN
        : Number(sanitized);
}

function setupNumericInput(input, allowNegative = false) {
    if (!input) {
        return;
    }

    input.addEventListener("input", () => {
        input.value = SantaBuscaStorage.sanitizeDecimal(
            input.value,
            allowNegative
        );
    });
}

function toast(message, type = "success") {
    const element = document.createElement("div");

    element.className = `toast${type === "error" ? " error" : ""}`;
    element.textContent = message;

    $("toastRegion").appendChild(element);

    setTimeout(() => element.remove(), 3200);
}

function setStatus(text, type = "info") {
    statusDiv.textContent = text;
    statusDiv.className = `status${type === "error" ? " error" : ""}`;
}

function categoryMeta(name) {
    return ({
        Supermercados: [
            "🛒",
            "Mercado",
            "Alimentos e itens do dia a dia"
        ],
        Farmácias: [
            "💊",
            "Farmácia",
            "Medicamentos e cuidados pessoais"
        ],
        Postos: [
            "⛽",
            "Combustível",
            "Gasolina, etanol e diesel"
        ]
    }[name] || ["📍", name, "Explore esta categoria"]);
}

function renderCategories() {
    categoryFilters.innerHTML = state.categorias
        .map((category) => {
            const [icon, label, description] = categoryMeta(category.nome);
            const selected = state.selectedCategory === category.nome;

            return `
                <button
                    type="button"
                    class="categoryCard ${selected ? "selected" : ""}"
                    data-category="${escapeHTML(category.nome)}"
                    aria-pressed="${selected}"
                >
                    <span class="categoryIcon">${icon}</span>
                    <span>
                        <strong>${label}</strong>
                        <small>${description}</small>
                    </span>
                </button>
            `;
        })
        .join("");
}

function getUserLocation() {
    const latitude = Number(userLatInput.value);
    const longitude = Number(userLonInput.value);

    return Number.isFinite(latitude) &&
        Number.isFinite(longitude) &&
        userLatInput.value !== "" &&
        userLonInput.value !== ""
        ? {
            lat: latitude,
            lon: longitude
        }
        : null;
}

function distance(lat1, lon1, lat2, lon2) {
    const radians = Math.PI / 180;
    const a =
        Math.sin(((lat2 - lat1) * radians) / 2) ** 2 +
        Math.cos(lat1 * radians) *
        Math.cos(lat2 * radians) *
        Math.sin(((lon2 - lon1) * radians) / 2) ** 2;

    return (
        6371 *
        2 *
        Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    );
}

function updateCoordsMap() {
    state.coordsMap = {};

    state.categorias.forEach((category) => {
        (category.locais || []).forEach((place) => {
            state.coordsMap[place.nome] = {
                lat: place.lat,
                lon: place.lon,
                categoria: category.nome
            };
        });
    });
}

function mergeDynamicEstablishments() {
    const establishments = SantaBuscaStorage.getEstablishments();

    establishments.forEach((establishment) => {
        const category = SantaBuscaStorage.getEstablishmentCategory(
            establishment
        );

        let categoryData = state.categorias.find(
            (item) => item.nome === category
        );

        if (!categoryData) {
            categoryData = {
                nome: category,
                locais: []
            };
            state.categorias.push(categoryData);
        }

        const alreadyExists = (categoryData.locais || []).some(
            (place) =>
                SantaBuscaStorage.normalizeText(place.nome) ===
                SantaBuscaStorage.normalizeText(establishment.nome)
        );

        if (!alreadyExists) {
            const [lat, lon] = String(establishment.coordenadas || "")
                .split(",")
                .map((value) => Number(value.trim()));

            categoryData.locais.push({
                nome: establishment.nome,
                lat: Number.isFinite(lat) ? lat : null,
                lon: Number.isFinite(lon) ? lon : null
            });
        }
    });
}

function filterProducts(products) {
    const query = (search.value || "").trim().toLowerCase();

    return products.filter((product) => {
        if (
            state.selectedCategory &&
            product.categoria !== state.selectedCategory
        ) {
            return false;
        }

        if (!query) {
            return true;
        }

        const names = (product.itens || []).flatMap((item) => [
            item.marca,
            ...(item.mercados || []).map((market) => market.nome)
        ]);

        return [
            product.nome,
            product.categoria,
            ...names
        ]
            .join(" ")
            .toLowerCase()
            .includes(query);
    });
}

function sortMarkets(markets) {
    const {
        preco,
        distancia
    } = state.filtrosOrdenacao;

    return [...markets].sort((a, b) => {
        if (preco && a.price !== b.price) {
            return a.price - b.price;
        }

        if (distancia) {
            return (a.distance ?? Infinity) - (b.distance ?? Infinity);
        }

        return 0;
    });
}

function priceFreshnessHTML(meta) {
    const timestamp = meta?.atualizadoEm ? new Date(meta.atualizadoEm).getTime() : NaN;
    if (!Number.isFinite(timestamp)) return '<small class="precoDesatualizado">🔴 Preço sem atualização registrada</small>';
    const days = Math.max(0, Math.floor((Date.now() - timestamp) / 86400000));
    if (days > 30) return `<small class="precoDesatualizado">🔴 Preço desatualizado há ${days} dia(s)</small>`;
    if (days === 0) return '<small class="precoAtualizado">🟢 Atualizado hoje</small>';
    if (days <= 7) return `<small class="precoAtualizado">🟢 Atualizado há ${days} dia(s)</small>`;
    return `<small class="precoAtualizado">🟡 Atualizado há ${days} dia(s)</small>`;
}

function trustHTML(meta) {
    const age = meta?.atualizadoEm
        ? Math.max(
            0,
            Math.floor(
                (Date.now() - new Date(meta.atualizadoEm).getTime()) /
                86400000
            )
        )
        : 999;

    const confirmations = Number(meta?.confirmacoes || 0);
    const reports = Number(meta?.denuncias || 0);

    if (age > 30 || reports >= 2) {
        return '<small class="trustBadge low">⚠ Preço pouco confiável</small>';
    }

    if (confirmations >= 3 || age <= 2) {
        return '<small class="trustBadge">✓ Preço confiável</small>';
    }

    return '<small class="trustBadge medium">◐ Confiança moderada</small>';
}

function reputationHTML(key) {
    const reputation = SantaBuscaStorage.getProductReputation(key);
    const icon =
        reputation.denuncias >= 3
            ? "⛔"
            : reputation.denuncias === 2
                ? "🔴"
                : reputation.denuncias === 1
                    ? "🟡"
                    : "🟢";

    return `
        <small class="priceStatus ${reputation.denuncias ? "pending" : "verified"}">
            ${icon} ${reputation.nivel}
            ${reputation.denuncias
                ? ` · ${reputation.denuncias} denúncia(s) deste produto`
                : ""}
        </small>
    `;
}

function renderEstablishments(category) {
    const categoryData = state.categorias.find(
        (item) => item.nome === category
    );

    if (!categoryData) {
        return "";
    }

    const location = getUserLocation();
    const places = (categoryData.locais || []).map((place) => ({
        ...place,
        distance:
            location &&
            Number.isFinite(place.lat) &&
            Number.isFinite(place.lon)
                ? distance(
                    location.lat,
                    location.lon,
                    place.lat,
                    place.lon
                )
                : null
    }));

    if (location) {
        places.sort(
            (a, b) =>
                (a.distance ?? Infinity) -
                (b.distance ?? Infinity)
        );
    }

    return `
        <section>
            <div class="subHeading">
                <h3>
                    Estabelecimentos de
                    ${escapeHTML(categoryMeta(category)[1].toLowerCase())}
                </h3>
                <span>${places.length} cadastrados</span>
            </div>

            <div class="locaisCarousel"><button class="carouselArrow carouselPrev" type="button" aria-label="Anterior">‹</button><div class="locaisGrid">
                ${places
                    .map(
                        (place) => `
                            <article class="localCard">
                                <strong>${escapeHTML(place.nome)}</strong>
                                <span>${escapeHTML(categoryMeta(category)[1])}</span>
                                <small>
                                    ${
                                        place.distance == null
                                            ? "Ative sua localização para ver a distância"
                                            : `📍 ${place.distance.toFixed(2)} km de você`
                                    }
                                </small>
                            </article>
                        `
                    )
                    .join("")}
            </div><button class="carouselArrow carouselNext" type="button" aria-label="Próximo">›</button></div>
        </section>
    `;
}

function renderProductCard(product) {
    const location = getUserLocation();

    return `
        <article class="cardPesquisa">
            <header class="pesquisaHeader">
                <span class="emojiGrande">${product.emoji || "📦"}</span>
                <div>
                    <h2>${escapeHTML(product.nome)}</h2>
                    <span class="categoriaPesquisa">
                        ${escapeHTML(categoryMeta(product.categoria)[1])}
                    </span>
                </div>
            </header>

            <div class="comparacoesGrid">
                ${(product.itens || [])
                    .map((item) => {
                        const markets = sortMarkets(
                            (item.mercados || []).map((market) => {
                                const coordinates =
                                    state.coordsMap[market.nome];

                                const key = SantaBuscaStorage.priceKey(
                                    product.nome,
                                    item.marca,
                                    market.nome
                                );

                                const meta =
                                    SantaBuscaStorage.ensurePriceMeta(
                                        key,
                                        market.preco
                                    );

                                const normalPrice =
                                    SantaBuscaStorage.currentNormalPrice(
                                        meta,
                                        market.preco
                                    );

                                const offer =
                                    SantaBuscaStorage.activeOffer(key);

                                const price =
                                    SantaBuscaStorage.effectivePrice(
                                        key,
                                        normalPrice
                                    );

                                return {
                                    ...market,
                                    key,
                                    meta,
                                    normalPrice,
                                    offer,
                                    price: Number(price),
                                    distance:
                                        location &&
                                        coordinates &&
                                        Number.isFinite(coordinates.lat) &&
                                        Number.isFinite(coordinates.lon)
                                            ? distance(
                                                location.lat,
                                                location.lon,
                                                coordinates.lat,
                                                coordinates.lon
                                            )
                                            : null
                                };
                            })
                        );

                        const availablePrices = markets
                            .filter(
                                (market) =>
                                    market.disponibilidade !== "esgotado"
                            )
                            .map((market) => market.price);

                        const minimumPrice = availablePrices.length
                            ? Math.min(...availablePrices)
                            : null;

                        return `
                            <div class="produtoComparacao">
                                <h3 class="marcaTitulo">
                                    ${escapeHTML(item.marca)}
                                </h3>

                                ${markets
                                    .map((market) => {
                                        const unavailable =
                                            market.disponibilidade ===
                                            "esgotado";

                                        return `
                                            <div class="mercadoLinha">
                                                <div class="mercadoInfo">
                                                    <strong>
                                                        ${escapeHTML(market.nome)}
                                                    </strong>

                                                    <small>
                                                        Preço por
                                                        ${escapeHTML(
                                                            market.unidade ||
                                                            "unidade"
                                                        )}
                                                        ${
                                                            market.distance != null
                                                                ? ` · ${market.distance.toFixed(2)} km`
                                                                : ""
                                                        }
                                                    </small>

                                                    ${reputationHTML(market.key)}
                                                    ${trustHTML(market.meta)}

                                                    ${priceFreshnessHTML(market.meta)}
                                                </div>

                                                <div class="mercadoPrecoBloco">
                                                    ${
                                                        unavailable
                                                            ? '<strong class="precoIndisponivel">Esgotado</strong>'
                                                            : market.offer
                                                                ? `
                                                                    <small class="precoNormalRiscado">
                                                                        ${formatPrice(market.normalPrice)}
                                                                    </small>
                                                                    <strong>
                                                                        ${formatPrice(market.price)}
                                                                    </strong>
                                                                    <small class="ofertaTxt">
                                                                        🏷️ Oferta
                                                                    </small>
                                                                `
                                                                : `
                                                                    <strong>
                                                                        ${formatPrice(market.price)}
                                                                    </strong>
                                                                `
                                                    }

                                                    ${
                                                        !unavailable &&
                                                        minimumPrice !== null &&
                                                        market.price === minimumPrice
                                                            ? '<small class="badgeBarato">Melhor preço</small>'
                                                            : ""
                                                    }

                                                    ${
                                                        !unavailable
                                                            ? `
                                                                <div class="priceActions">
                                                                    <button
                                                                        class="miniAction confirmarPreco"
                                                                        data-confirm-key="${escapeHTML(market.key)}"
                                                                    >
                                                                        ✓ Confirmar (+2)
                                                                    </button>

                                                                    <button
                                                                        class="miniAction denunciarPreco"
                                                                        data-report-key="${escapeHTML(market.key)}"
                                                                        data-product="${escapeHTML(product.nome)}"
                                                                        data-brand="${escapeHTML(item.marca)}"
                                                                        data-market="${escapeHTML(market.nome)}"
                                                                        data-price="${market.price}"
                                                                    >
                                                                        ⚠ Denunciar
                                                                    </button>

                                                                    <button
                                                                        class="miniAction alertarPreco ${SantaBuscaStorage.canCreatePriceAlert() ? "" : "alertaBloqueado"}"
                                                                        data-alert-key="${escapeHTML(market.key)}"
                                                                        data-product="${escapeHTML(product.nome)}"
                                                                        data-brand="${escapeHTML(item.marca)}"
                                                                        data-market="${escapeHTML(market.nome)}"
                                                                        data-price="${market.price}"
                                                                        ${SantaBuscaStorage.canCreatePriceAlert() ? "" : "disabled"}
                                                                    >
                                                                        🔔 Me avise quando baixar
                                                                    </button>

                                                                    <button
                                                                        class="miniAction historicoPreco"
                                                                        data-history-key="${escapeHTML(market.key)}"
                                                                        data-product="${escapeHTML(product.nome)}"
                                                                        data-brand="${escapeHTML(item.marca)}"
                                                                        data-market="${escapeHTML(market.nome)}"
                                                                    >
                                                                        📈 Histórico
                                                                    </button>
                                                                </div>
                                                            `
                                                            : ""
                                                    }
                                                </div>
                                            </div>
                                        `;
                                    })
                                    .join("")}
                            </div>
                        `;
                    })
                    .join("")}
            </div>
        </article>
    `;
}

function renderSearchSuggestions() {
    const list = $("searchSuggestions");
    if (!list) return;
    const names = new Set();
    (state.produtos || []).forEach((product) => {
        names.add(product.nome);
        (product.itens || []).forEach((item) => names.add(`${product.nome} · ${item.marca}`));
    });
    (state.categorias || []).forEach((category) => (category.locais || []).forEach((place) => names.add(place.nome)));
    SantaBuscaStorage.getEstablishments().forEach((place) => names.add(place.nome));
    list.innerHTML = [...names].sort((a,b) => a.localeCompare(b, "pt-BR")).slice(0, 80).map((name) => `<option value="${escapeHTML(name)}"></option>`).join("");
}

function render() {
    const products = filterProducts(state.produtos);

    count.textContent = products.length;

    $("countLabel").textContent = state.selectedCategory
        ? `de ${
            state.produtos.filter(
                (product) =>
                    product.categoria === state.selectedCategory
            ).length
        } produtos na categoria`
        : "resultados encontrados";

    $("resultsTitle").textContent = state.selectedCategory
        ? `${categoryMeta(state.selectedCategory)[1]}: produtos e estabelecimentos`
        : search.value.trim()
            ? "Resultados da pesquisa"
            : "Explore as categorias";

    if (!state.selectedCategory && !search.value.trim()) {
        grid.innerHTML = `
            <div class="emptyHero">
                <span class="categoryPointer" aria-hidden="true">👆</span>
                <h2>Escolha uma categoria para começar</h2>
                <p>
                    Mercado, Farmácia ou Combustível.
                    Você também pode pesquisar a qualquer momento.
                </p>
            </div>
        `;
        return;
    }

    grid.innerHTML = `
        ${
            state.selectedCategory
                ? renderEstablishments(state.selectedCategory)
                : ""
        }

        ${
            products.length
                ? `
                    <section class="products">
                        <div class="subHeading">
                            <h3>Produtos encontrados</h3>
                            <span>${products.length} resultado(s)</span>
                        </div>

                        ${products.map(renderProductCard).join("")}
                    </section>
                `
                : `
                    <div class="empty">
                        <h2>Nenhum resultado encontrado</h2>
                        <p>
                            Tente outro termo ou escolha uma categoria
                            diferente.
                        </p>
                    </div>
                `
        }
    `;
}

function updatePoints() {
    userPoints.textContent =
        SantaBuscaStorage.getMonthlyStats().points;
}

function renderPriceThermometer() {
    const box = document.getElementById("price-thermometer");
    if (!box) return;

    const data = SantaBuscaStorage.getPriceThermometer();

    if (!data.disponivel) {
        box.innerHTML = `
            <span class="thermometerIcon">🌡️</span>
            <div>
                <strong>Termômetro de preços de Santa Cruz</strong>
                <small>Ainda não há dados suficientes este mês para calcular a variação.</small>
            </div>
        `;
        return;
    }

    const variacao = data.variacaoPercentual;
    const subiu = variacao > 0.05;
    const desceu = variacao < -0.05;
    const icone = subiu ? "📈" : desceu ? "📉" : "➖";
    const cor = subiu ? "thermometerUp" : desceu ? "thermometerDown" : "thermometerFlat";
    const sinal = variacao > 0 ? "+" : "";

    box.classList.add(cor);
    box.innerHTML = `
        <span class="thermometerIcon">${icone}</span>
        <div>
            <strong>Termômetro de preços de Santa Cruz: ${sinal}${variacao.toFixed(1)}% este mês</strong>
            <small>
                Baseado em ${data.amostras} produto${data.amostras === 1 ? "" : "s"} acompanhado${data.amostras === 1 ? "" : "s"}
                (${data.produtosSubiram} ${data.produtosSubiram === 1 ? "subiu" : "subiram"}, ${data.produtosCairam} ${data.produtosCairam === 1 ? "caiu" : "cairam"})
            </small>
        </div>
    `;
}

function requestGeo() {
    if (!navigator.geolocation) {
        toast(
            "Seu navegador não suporta geolocalização.",
            "error"
        );
        return;
    }

    btnGeoHeader.disabled = true;
    btnGeoHeader.textContent = "Localizando...";

    navigator.geolocation.getCurrentPosition(
        (position) => {
            userLatInput.value =
                position.coords.latitude.toFixed(6);
            userLonInput.value =
                position.coords.longitude.toFixed(6);

            btnGeoHeader.disabled = false;
            btnGeoHeader.textContent =
                "📍 Localização ativa";

            toast("Localização obtida!");
            render();
        },
        () => {
            btnGeoHeader.disabled = false;
            btnGeoHeader.textContent =
                "📍 Usar minha localização";

            toast(
                "Não foi possível obter sua localização.",
                "error"
            );
        },
        {
            enableHighAccuracy: true,
            timeout: 10000
        }
    );
}

function compressImage(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onerror = () =>
            reject(new Error("Não foi possível ler a imagem."));

        reader.onload = () => {
            const image = new Image();

            image.onerror = () =>
                reject(new Error("Arquivo de imagem inválido."));

            image.onload = () => {
                let width = image.width;
                let height = image.height;
                const max = 900;

                if (Math.max(width, height) > max) {
                    const ratio =
                        max / Math.max(width, height);

                    width = Math.round(width * ratio);
                    height = Math.round(height * ratio);
                }

                const canvas = document.createElement("canvas");
                canvas.width = width;
                canvas.height = height;

                canvas
                    .getContext("2d")
                    .drawImage(image, 0, 0, width, height);

                let quality = 0.72;
                let data = canvas.toDataURL(
                    "image/jpeg",
                    quality
                );

                const bytes = () =>
                    Math.ceil(
                        (data.length -
                            data.indexOf(",") -
                            1) *
                            3 /
                            4
                    );

                while (
                    bytes() > 300 * 1024 &&
                    quality > 0.35
                ) {
                    quality -= 0.07;
                    data = canvas.toDataURL(
                        "image/jpeg",
                        quality
                    );
                }

                if (bytes() > 300 * 1024) {
                    reject(
                        new Error(
                            "A imagem continua maior que 300 KB. Escolha outra imagem."
                        )
                    );
                    return;
                }

                resolve(data);
            };

            image.src = reader.result;
        };

        reader.readAsDataURL(file);
    });
}

function openReport(data) {
    reportContext = data;

    $("reportTarget").innerHTML = `
        <strong>
            ${escapeHTML(data.product)} · ${escapeHTML(data.brand)}
        </strong>
        <span>${escapeHTML(data.market)}</span>
        <small>Preço atual: ${formatPrice(data.price)}</small>
    `;

    $("reportPrice").value = "";
    $("reportProof").value = "";
    $("reportFeedback").textContent = "";
    $("reportModal").hidden = false;
    $("reportPrice").focus();
}

function closeReport() {
    $("reportModal").hidden = true;
    reportContext = null;
}

async function submitReport() {
    if (!reportContext) {
        return;
    }

    const price = parseDecimalInput($("reportPrice").value);
    const file = $("reportProof").files[0];

    if (!Number.isFinite(price) || price <= 0) {
        $("reportFeedback").textContent =
            "Informe um preço válido.";
        return;
    }

    if (!file) {
        $("reportFeedback").textContent =
            "O comprovante é obrigatório para enviar a denúncia.";
        return;
    }

    try {
        const proof = await compressImage(file);

        const result = SantaBuscaStorage.reportPrice({
            chave: reportContext.key,
            produto: reportContext.product,
            marca: reportContext.brand,
            estabelecimento: reportContext.market,
            precoAtual: reportContext.price,
            novoPreco: price,
            comprovante: proof
        });

        if (!result.ok) {
            $("reportFeedback").textContent =
                "Você já denunciou este preço neste mês.";
            return;
        }

        closeReport();
        updatePoints();
        toast(
            "Denúncia registrada com comprovante! +5 pontos"
        );
        render();
    } catch (error) {
        $("reportFeedback").textContent = error.message;
    }
}

function openHistory(key, product, brand, market) {
    const prices =
        SantaBuscaStorage.read(
            SantaBuscaStorage.KEYS.prices,
            {}
        );

    const meta = prices[key] || null;

    $("historyTarget").textContent =
        `${product} · ${brand} · ${market}`;

    const history = Array.isArray(meta?.historico)
        ? [...meta.historico].reverse()
        : [];

    $("historyList").innerHTML = history.length
        ? history
            .map(
                (item) => `
                    <div class="historyItem">
                        <strong>${formatPrice(item.preco)}</strong>
                        <small>
                            ${
                                new Intl.DateTimeFormat("pt-BR", {
                                    dateStyle: "short",
                                    timeStyle: "short"
                                }).format(new Date(item.data))
                            }
                            · ${escapeHTML(item.origem || "registro")}
                        </small>
                    </div>
                `
            )
            .join("")
        : '<div class="mutedBox">Ainda não há histórico registrado.</div>';

    $("historyModal").hidden = false;
}

function closeHistory() {
    $("historyModal").hidden = true;
}

categoryFilters.addEventListener("click", (event) => {
    const button = event.target.closest("[data-category]");

    if (!button) {
        return;
    }

    state.selectedCategory =
        state.selectedCategory === button.dataset.category
            ? null
            : button.dataset.category;

    renderCategories();
    render();
});

$("showAllCategories").onclick = () => {
    state.selectedCategory = null;
    renderCategories();
    render();
};

search.addEventListener(
    "input",
    debounce(() => {
        render();
    }, 220)
);

// O Radar contabiliza uma busca real, não cada letra digitada.
search.addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    const query = search.value.trim();
    if (query.length >= 2) {
        SantaBuscaStorage.recordSearch(query);
        render();
    }
});

$("clearBtn").onclick = () => {
    search.value = "";
    render();
    search.focus();
};

setupNumericInput(userLatInput, true);
setupNumericInput(userLonInput, true);
setupNumericInput($("reportPrice"), false);

[userLatInput, userLonInput].forEach((input) => {
    input.addEventListener(
        "input",
        debounce(render)
    );
});

document
    .querySelectorAll(".ordenacaoBtn")
    .forEach((button) => {
        button.onclick = () => {
            const key = button.dataset.ordenacao;
            const active =
                Object.values(state.filtrosOrdenacao)
                    .filter(Boolean)
                    .length;

            if (
                state.filtrosOrdenacao[key] &&
                active === 1
            ) {
                return;
            }

            state.filtrosOrdenacao[key] =
                !state.filtrosOrdenacao[key];

            document
                .querySelectorAll(".ordenacaoBtn")
                .forEach((item) => {
                    const activeState =
                        state.filtrosOrdenacao[
                            item.dataset.ordenacao
                        ];

                    item.classList.toggle(
                        "ativo",
                        activeState
                    );

                    item.setAttribute(
                        "aria-pressed",
                        String(activeState)
                    );
                });

            render();
        };
    });

grid.addEventListener("click", (event) => {
    const reportButton =
        event.target.closest("[data-report-key]");

    if (reportButton) {
        openReport({
            key: reportButton.dataset.reportKey,
            product: reportButton.dataset.product,
            brand: reportButton.dataset.brand,
            market: reportButton.dataset.market,
            price: Number(reportButton.dataset.price)
        });

        return;
    }

    const confirmButton =
        event.target.closest("[data-confirm-key]");

    if (confirmButton) {
        const result =
            SantaBuscaStorage.registerNoteAction(
                confirmButton.dataset.confirmKey,
                "confirmar"
            );

        if (!result.ok) {
            toast(
                "Você já confirmou este preço neste mês.",
                "error"
            );
            return;
        }

        updatePoints();
        toast("Preço confirmado! +2 pontos");
        render();

        return;
    }

    const historyButton =
        event.target.closest("[data-history-key]");

    if (historyButton) {
        openHistory(
            historyButton.dataset.historyKey,
            historyButton.dataset.product,
            historyButton.dataset.brand,
            historyButton.dataset.market
        );
    }
});

$("reportClose").onclick = closeReport;
$("reportCancel").onclick = closeReport;
$("reportSubmit").onclick = submitReport;

$("reportModal").onclick = (event) => {
    if (event.target === $("reportModal")) {
        closeReport();
    }
};

$("historyClose").onclick = closeHistory;

$("historyModal").onclick = (event) => {
    if (event.target === $("historyModal")) {
        closeHistory();
    }
};

btnGeoHeader.onclick = requestGeo;

document.addEventListener("click", (event) => {
    const arrow = event.target.closest(".carouselPrev, .carouselNext");
    if (arrow) {
        const carousel = arrow.closest(".locaisCarousel");
        const grid = carousel?.querySelector(".locaisGrid");
        if (grid) {
            const amount = Math.max(grid.clientWidth * 0.82, 260);
            grid.scrollBy({
                left: arrow.classList.contains("carouselPrev") ? -amount : amount,
                behavior: "smooth"
            });
        }
        return;
    }

    const button = event.target.closest(".alertarPreco");
    if (!button) return;
    if (!SantaBuscaStorage.canCreatePriceAlert()) {
        toast("🔒 Você precisa de mais de 25 pontos neste mês para usar este alerta.");
        return;
    }
    const current = Number(button.dataset.price || 0);
    const target = Number(window.prompt(`Avise quando o preço ficar abaixo de R$ ${current.toFixed(2).replace(".", ",")}.\n\nDigite o preço desejado:`, Math.max(0, current - 0.01).toFixed(2).replace(".", ",").replace(".", ","))?.replace(",", "."));
    if (!Number.isFinite(target) || target <= 0) return;
    const result = SantaBuscaStorage.addPriceAlert({ chave: button.dataset.alertKey, produto: button.dataset.product, marca: button.dataset.brand, estabelecimento: button.dataset.market, precoAlvo: target });
    toast(result.ok ? "🔔 Alerta criado! Você será avisado quando o preço baixar." : "Você já possui esse alerta.");
});

async function load() {
    setStatus("Carregando dados...");

    try {
        let data;

        try {
            const response = await fetch("dados.json");

            if (!response.ok) {
                throw new Error("Falha ao carregar dados.json.");
            }

            data = await response.json();
        } catch (error) {
            data = DADOS_EMBUTIDOS;
        }

        state.produtos = SantaBuscaStorage.getCatalogProducts(
            data.produtos || []
        );

        state.categorias = JSON.parse(
            JSON.stringify(data.categorias || [])
        );

        mergeDynamicEstablishments();
        updateCoordsMap();
        renderCategories();
        renderSearchSuggestions();
        updatePoints();
        renderPriceThermometer();
        render();

        setStatus(
            "Dados carregados. Escolha uma categoria ou pesquise."
        );
    } catch (error) {
        console.error(error);
        setStatus(
            "Erro ao carregar os dados.",
            "error"
        );
    }
}

document.addEventListener("santaBusca:serverReady", () => {
    load();
});

load();
