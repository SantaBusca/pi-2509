const DADOS_EMBUTIDOS = {
  "produtos": [
    {
      "nome": "Arroz",
      "emoji": "🍚",
      "categoria": "Supermercados",
      "itens": [
        {
          "marca": "Tio João",
          "mercados": [
            {
              "nome": "Varejão Supermercado",
              "preco": 22.9
            },
            {
              "nome": "Supermercado Rodrigues",
              "preco": 21.5
            },
            {
              "nome": "Mercadinho Santa Rita",
              "preco": 24.9
            }
          ]
        },
        {
          "marca": "Caçarola",
          "mercados": [
            {
              "nome": "Mercadinho Santa Rita",
              "preco": 20.9
            },
            {
              "nome": "Supermercado Rodrigues",
              "preco": 19.99
            },
            {
              "nome": "Varejão Supermercado",
              "preco": 21.9
            }
          ]
        }
      ]
    },
    {
      "nome": "Feijão",
      "emoji": "🫘",
      "categoria": "Supermercados",
      "itens": [
        {
          "marca": "Kicaldo",
          "mercados": [
            {
              "nome": "Varejão Supermercado",
              "preco": 8.9
            },
            {
              "nome": "Supermercado Rodrigues",
              "preco": 7.99
            },
            {
              "nome": "Mercadinho Santa Rita",
              "preco": 9.5
            }
          ]
        }
      ]
    },
    {
      "nome": "Macarrão",
      "emoji": "🍝",
      "categoria": "Supermercados",
      "itens": [
        {
          "marca": "Vitarella",
          "mercados": [
            {
              "nome": "Varejão Supermercado",
              "preco": 5.99
            },
            {
              "nome": "Supermercado Rodrigues",
              "preco": 5.5
            },
            {
              "nome": "Mercadinho Santa Rita",
              "preco": 6.2
            }
          ]
        }
      ]
    },
    {
      "nome": "Café",
      "emoji": "☕",
      "categoria": "Supermercados",
      "itens": [
        {
          "marca": "Santa Clara",
          "mercados": [
            {
              "nome": "Varejão Supermercado",
              "preco": 14.9
            },
            {
              "nome": "Supermercado Rodrigues",
              "preco": 15.2
            },
            {
              "nome": "Mercadinho Santa Rita",
              "preco": 14.5
            }
          ]
        }
      ]
    },
    {
      "nome": "Leite",
      "emoji": "🥛",
      "categoria": "Supermercados",
      "itens": [
        {
          "marca": "Betânia",
          "mercados": [
            {
              "nome": "Varejão Supermercado",
              "preco": 6.99
            },
            {
              "nome": "Supermercado Rodrigues",
              "preco": 7.2
            },
            {
              "nome": "Mercadinho Santa Rita",
              "preco": 6.8
            }
          ]
        }
      ]
    },
    {
      "nome": "Dipirona",
      "emoji": "💊",
      "categoria": "Farmácias",
      "itens": [
        {
          "marca": "Neo Química",
          "mercados": [
            {
              "nome": "Farmácia Chacon",
              "preco": 7.5
            },
            {
              "nome": "Farmácia Santa Cruz",
              "preco": 6.7
            },
            {
              "nome": "Farmácia Tradição Rocha",
              "preco": 6.99
            }
          ]
        }
      ]
    },
    {
      "nome": "Paracetamol",
      "emoji": "💉",
      "categoria": "Farmácias",
      "itens": [
        {
          "marca": "Tylenol",
          "mercados": [
            {
              "nome": "Farmácia Chacon",
              "preco": 13.5
            },
            {
              "nome": "Farmácia Santa Cruz",
              "preco": 11.99
            },
            {
              "nome": "Farmácia Tradição Rocha",
              "preco": 12.9
            }
          ]
        }
      ]
    },
    {
      "nome": "Ibuprofeno",
      "emoji": "🩺",
      "categoria": "Farmácias",
      "itens": [
        {
          "marca": "Alivium",
          "mercados": [
            {
              "nome": "Farmácia Chacon",
              "preco": 19.5
            },
            {
              "nome": "Farmácia Santa Cruz",
              "preco": 17.99
            },
            {
              "nome": "Farmácia Tradição Rocha",
              "preco": 18.9
            }
          ]
        }
      ]
    },
    {
      "nome": "Gasolina",
      "emoji": "⛽",
      "categoria": "Postos",
      "itens": [
        {
          "marca": "Comum",
          "mercados": [
            {
              "nome": "Posto Santa Rita",
              "preco": 6.29
            },
            {
              "nome": "Posto Apollo 11",
              "preco": 6.19
            },
            {
              "nome": "Rede StopCar",
              "preco": 6.35
            }
          ]
        }
      ]
    },
    {
      "nome": "Etanol",
      "emoji": "🛢️",
      "categoria": "Postos",
      "itens": [
        {
          "marca": "Etanol Comum",
          "mercados": [
            {
              "nome": "Posto Santa Rita",
              "preco": 4.79
            },
            {
              "nome": "Posto Apollo 11",
              "preco": 4.69
            },
            {
              "nome": "Rede StopCar",
              "preco": 4.85
            }
          ]
        }
      ]
    }
  ],
  "categorias": [
    {
      "nome": "Supermercados",
      "locais": [
        {
          "nome": "Varejão Supermercado",
          "lat": -6.2291,
          "lon": -36.0123
        },
        {
          "nome": "Supermercado Rodrigues",
          "lat": -6.2245,
          "lon": -36.015
        },
        {
          "nome": "Mercadinho Santa Rita",
          "lat": -6.231,
          "lon": -36.009
        }
      ]
    },
    {
      "nome": "Farmácias",
      "locais": [
        {
          "nome": "Farmácia Chacon",
          "lat": -6.2272,
          "lon": -36.0115
        },
        {
          "nome": "Farmácia Santa Cruz",
          "lat": -6.226,
          "lon": -36.013
        },
        {
          "nome": "Farmácia Tradição Rocha",
          "lat": -6.2285,
          "lon": -36.0102
        }
      ]
    },
    {
      "nome": "Postos",
      "locais": [
        {
          "nome": "Posto Santa Rita",
          "lat": -6.235,
          "lon": -36.004
        },
        {
          "nome": "Posto Apollo 11",
          "lat": -6.219,
          "lon": -36.021
        },
        {
          "nome": "Rede StopCar",
          "lat": -6.241,
          "lon": -36.001
        }
      ]
    }
  ]
};
