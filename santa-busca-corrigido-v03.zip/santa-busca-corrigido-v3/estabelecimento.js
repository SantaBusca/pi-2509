"use strict";

(function () {
    const S = SantaBuscaStorage;
    let temp = {};
    let logo = null;
    let foto = null;

    const $ = (id) => document.getElementById(id);

    function show(id) {
        document
            .querySelectorAll(".screen")
            .forEach((screen) => {
                screen.classList.toggle(
                    "active",
                    screen.id === id
                );
            });

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }

    function err(element, on) {
        element?.classList.toggle("field-error", on);
    }

    function email(value) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    }

    function validateCNPJField(input) {
        return S.validateCNPJ(input.value);
    }

    function sanitizeCNPJInput(input) {
        S.reformatKeepingCaret(input, S.formatCNPJ);
        err(
            $("cad-cnpj-field"),
            input.value !== "" &&
            !validateCNPJField(input)
        );
    }

    document
        .querySelectorAll("[data-goto]")
        .forEach((button) => {
            button.onclick = () => show(button.dataset.goto);
        });

    $("go-cadastro").onclick = () =>
        show("screen-3a");

    $("go-login").onclick = () =>
        show("screen-2");

    $("forgot-link").onclick = () =>
        alert(
            "Para o protótipo, a recuperação de senha será ligada ao banco de dados futuramente."
        );

    const dias = [
        ["seg", "Segunda-feira"],
        ["ter", "Terça-feira"],
        ["qua", "Quarta-feira"],
        ["qui", "Quinta-feira"],
        ["sex", "Sexta-feira"],
        ["sab", "Sábado"],
        ["dom", "Domingo"]
    ];

    function dropdown(
        id,
        toggle,
        panel,
        display,
        multi,
        options,
        placeholder
    ) {
        let selected = multi ? [] : null;
        const root = $(id);
        const panelEl = $(panel);

        options.forEach((option) => {
            const element = document.createElement("div");

            element.className = "dropdown-option";
            element.innerHTML = `
                <span class="${multi ? "checkbox" : "radio"}"></span>
                <span>${option[1]}</span>
            `;

            element.onclick = () => {
                if (multi) {
                    selected = selected.includes(option[0])
                        ? selected.filter(
                            (value) => value !== option[0]
                        )
                        : [...selected, option[0]];

                    element.classList.toggle(
                        "selected",
                        selected.includes(option[0])
                    );

                    $(display).textContent = selected.length
                        ? options
                            .filter((item) =>
                                selected.includes(item[0])
                            )
                            .map((item) => item[1])
                            .join(", ")
                        : placeholder;

                    $(display).className = selected.length
                        ? "chosen"
                        : "placeholder";
                } else {
                    selected = option[0];

                    panelEl
                        .querySelectorAll(".dropdown-option")
                        .forEach((item) =>
                            item.classList.remove("selected")
                        );

                    element.classList.add("selected");
                    $(display).textContent = option[1];
                    $(display).className = "chosen";
                    root.classList.remove("open");
                }
            };

            panelEl.appendChild(element);
        });

        $(toggle).onclick = () =>
            root.classList.toggle("open");

        document.addEventListener("click", (event) => {
            if (!root.contains(event.target)) {
                root.classList.remove("open");
            }
        });

        return {
            get: () => selected,
            reset: () => {
                selected = multi ? [] : null;
                $(display).textContent = placeholder;
                $(display).className = "placeholder";

                panelEl
                    .querySelectorAll(".dropdown-option")
                    .forEach((item) =>
                        item.classList.remove("selected")
                    );
            }
        };
    }

    const diasDropdown = dropdown(
        "dias-dropdown",
        "dias-toggle",
        "dias-panel",
        "dias-display",
        true,
        dias,
        "Selecione os dias"
    );

    const tipoDropdown = dropdown(
        "tipo-dropdown",
        "tipo-toggle",
        "tipo-panel",
        "tipo-display",
        false,
        [
            ["farmacia", "Farmácia"],
            ["comercio", "Comércio"],
            ["posto", "Posto de gasolina"],
            ["supermercado", "Supermercado"]
        ],
        "Selecione o tipo"
    );

    $("form-login").onsubmit = async (event) => {
        event.preventDefault();

        const emailValue = $("login-email")
            .value
            .trim()
            .toLowerCase();

        const password = $("login-senha").value;
        const validEmail = email(emailValue);

        err(
            $("login-email-field"),
            !validEmail
        );

        err(
            $("login-senha-field"),
            !password
        );

        if (!validEmail || !password) {
            $("login-alert").textContent =
                "Preencha os campos corretamente.";
            $("login-alert").classList.add("visible");
            return;
        }

        let establishment = null;

        if (window.SantaBuscaAPI?.enabled()) {
            try {
                const response = await window.SantaBuscaAPI.login(
                    emailValue,
                    password
                );
                establishment = response.establishment;
                S.saveEstablishment(establishment);
            } catch (error) {
            }
        }

        if (!establishment) {
            establishment = S.getEstablishments().find(
                (item) =>
                    String(item.email).toLowerCase() === emailValue &&
                    item.senha === password
            );
        }

        if (!establishment) {
            $("login-alert").textContent =
                "Email ou senha incorretos.";
            $("login-alert").classList.add("visible");
            return;
        }

        S.write(S.KEYS.currentEstablishment, establishment.id);
        window.location.href = "dashboard-estabelecimento.html";
    };

    $("form-cadastro-a").onsubmit = (event) => {
        event.preventDefault();

        const emailValue = $("cad-email")
            .value
            .trim()
            .toLowerCase();

        const name = $("cad-nome").value.trim();
        const cnpj = $("cad-cnpj").value.trim();
        const password = $("cad-senha").value;
        const confirmation = $("cad-confirma").value;

        const fields = [
            [
                "cad-email-field",
                !email(emailValue)
            ],
            [
                "cad-nome-field",
                !name
            ],
            [
                "cad-cnpj-field",
                !S.validateCNPJ(cnpj)
            ],
            [
                "cad-senha-field",
                password.length < 6
            ],
            [
                "cad-confirma-field",
                password !== confirmation
            ]
        ];

        fields.forEach(([id, invalid]) =>
            err($(id), invalid)
        );

        if (fields.some(([, invalid]) => invalid)) {
            $("cad-a-alert").textContent =
                "Preencha todos os campos corretamente.";
            $("cad-a-alert").classList.add("visible");
            return;
        }

        if (
            S.getEstablishments().some(
                (item) =>
                    String(item.email).toLowerCase() ===
                    emailValue
            )
        ) {
            $("cad-a-alert").textContent =
                "Já existe um estabelecimento com este email.";
            $("cad-a-alert").classList.add("visible");
            return;
        }

        $("cad-a-alert").classList.remove("visible");

        temp = {
            email: emailValue,
            nome: name,
            cnpj: S.formatCNPJ(cnpj),
            senha: password
        };

        show("screen-3b");
    };

    $("cad-cnpj").addEventListener(
        "input",
        (event) => {
            sanitizeCNPJInput(event.target);
        }
    );

    $("cad-cnpj").addEventListener(
        "blur",
        (event) => {
            event.target.value =
                S.formatCNPJ(event.target.value);

            err(
                $("cad-cnpj-field"),
                !S.validateCNPJ(event.target.value)
            );
        }
    );

    $("cad-coord").addEventListener("input", (event) => {
        const parts = event.target.value.split(",");

        event.target.value = parts
            .slice(0, 2)
            .map((part) =>
                S.sanitizeDecimal(part, true)
            )
            .join(", ");
    });

    $("form-cadastro-b").onsubmit = (event) => {
        event.preventDefault();

        const coordinates =
            $("cad-coord").value.trim();

        const address =
            $("cad-endereco").value.trim();

        const opening =
            $("cad-abertura").value;

        const closing =
            $("cad-fechamento").value;

        const selectedDays = diasDropdown.get();
        const selectedType = tipoDropdown.get();

        const fields = [
            [
                "cad-coord-field",
                !S.isValidCoordinatePair(coordinates)
            ],
            [
                "cad-endereco-field",
                !address
            ],
            [
                "cad-abertura-field",
                !opening
            ],
            [
                "cad-fechamento-field",
                !closing
            ],
            [
                "cad-dias-field",
                !selectedDays.length
            ],
            [
                "cad-tipo-field",
                !selectedType
            ]
        ];

        fields.forEach(([id, invalid]) =>
            err($(id), invalid)
        );

        if (fields.some(([, invalid]) => invalid)) {
            $("cad-b-alert").textContent =
                "Preencha todos os campos corretamente.";
            $("cad-b-alert").classList.add("visible");
            return;
        }

        Object.assign(temp, {
            coordenadas: coordinates,
            endereco: address,
            abertura: opening,
            fechamento: closing,
            dias: selectedDays,
            tipo: selectedType
        });

        show("screen-3c");
    };

    function upload(dropId, inputId, setter) {
        const drop = $(dropId);
        const input = $(inputId);

        const pick = () => input.click();

        drop.onclick = pick;

        drop.onkeydown = (event) => {
            if (
                event.key === "Enter" ||
                event.key === " "
            ) {
                event.preventDefault();
                pick();
            }
        };

        input.onchange = () => {
            const file = input.files?.[0];

            if (!file) {
                return;
            }

            const reader = new FileReader();

            reader.onload = (event) => {
                setter(event.target.result);

                drop.innerHTML = `
                    <img
                        src="${event.target.result}"
                        alt="Pré-visualização"
                    >
                `;
            };

            reader.readAsDataURL(file);
        };
    }

    upload(
        "logo-drop",
        "input-logo",
        (value) => (logo = value)
    );

    upload(
        "foto-drop",
        "input-foto",
        (value) => (foto = value)
    );

    $("concluir-btn").onclick = async () => {
        const payload = {
            ...temp,
            logo,
            foto
        };

        let establishment = null;

        if (window.SantaBuscaAPI?.enabled()) {
            try {
                const response = await window.SantaBuscaAPI.register(payload);
                establishment = response.establishment;
                S.saveEstablishment(establishment);
            } catch (error) {
                $("cad-c-alert").textContent =
                    error.message || "Não foi possível concluir o cadastro no banco de dados.";
                $("cad-c-alert").classList.add("visible");
                return;
            }
        } else {
            establishment = S.saveEstablishment(payload);
        }

        S.write(S.KEYS.currentEstablishment, establishment.id);
        window.location.href = "dashboard-estabelecimento.html";
    };
})();
