# Santa Busca — Handoff de continuação

Este arquivo existe para você colar no início de uma conversa com outra IA
(ou comigo mesmo, em outra sessão) caso o trabalho precise continuar sem
perder o contexto. Cole o conteúdo abaixo como primeira mensagem, junto
com o zip do projeto.

---

## PROMPT PARA A PRÓXIMA IA (cole isso)

Você vai continuar o desenvolvimento do "Santa Busca", um app de comparação
de preços colaborativo para Santa Cruz/RN (categorias como Supermercados,
Farmácias, Postos). Stack: front-end em HTML/CSS/JS puro (sem framework),
back-end Node.js + MySQL (`server.js`, `mysql2`), com `localStorage` como
cache/fallback offline e sincronização automática via `api-client.js`
(debounce de 450ms).

**Regras inegociáveis do dono do projeto (não quebre isso):**
1. Preserve 100% o design, cores, fontes e funcionalidades já existentes.
   Não reescreva nada do zero — edite incrementalmente.
2. O tema visual é ESCURO (`--bg:#0b0d12`, `--panel:#141820`,
   `--panel2:#1a202b`, `--accent:#dfff3f`). Nunca use cores brancas/claras
   fixas (`rgba(255,255,255,.7+)`) em cards — use as variáveis do tema.
3. Antes de dizer "pronto", teste de verdade (ou pelo menos releia o fluxo
   completo) — o histórico deste projeto já teve casos de "parecia certo
   no código mas quebrava no navegador" (bug de `dropdown()` em
   `estabelecimento.js`, e bug de SQL em `pontos_eventos`/`server.js`).
4. Regras de negócio já fixadas: reputação por produto
   (0/1/2/3+ denúncias no mês = Ótima/Atenção/Ruim/Muito ruim); ranking do
   estabelecimento soma todas as denúncias do mês com tolerância de 3.

## O que já foi implementado (não refazer)

- **Bug crítico corrigido**: `server.js` consultava `chave` na tabela
  `pontos_eventos` (que não tem essa coluna) — trocado para
  `acoes_usuario` (tabela correta, tem `chave` e `acao`).
- **Cards cinza/claros corrigidos**: `.summaryCard`, `.radarStat`,
  `.radarPanel`, `.publicHeroCard`, `.publicProductCard`,
  `.publicLogoPlaceholder`, `.publicFacts`, `.publicCoverWrap` agora usam
  `var(--panel)` / `var(--panel2)` / `var(--border)` em vez de branco fixo.
- **Selo "🏆 Melhor preço da região"**: nova função
  `SantaBuscaStorage.isBestRegionalPrice(nome, marca, preco, nomeEstabelecimento)`
  em `app-storage.js`. Aplicada no painel do lojista
  (`dashboard-estabelecimento.js`, função `renderProducts`) e na página
  pública (`estabelecimento-publico.html`, função `productCard`).
- **Banner ativo de demanda não atendida**: em
  `dashboard-estabelecimento.js`, função `renderCommerceRadar()`, quando
  `radar.unmet.length > 0` aparece um banner destacado no topo do Radar
  (classe CSS `.radarAlertBanner`) com link âncora para `#my-products`.
  (O cálculo de `unmet` já existia antes, em `getCommerceRadar()` —
  só foi tornado visível/ativo.)
- **Selo de confiança + QR code**: novo card no painel do lojista
  (`dashboard-estabelecimento.html`, `<div id="trust-seal">`), preenchido
  por `renderTrustSeal()` em `dashboard-estabelecimento.js`. Usa a
  biblioteca `qrcode.js` via CDN (`https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js`)
  para gerar um QR code apontando para a página pública do estabelecimento,
  com botão de download.
- **Página "Cesta Ideal"** (`cesta-ideal.html` + `cesta-ideal.js`, novos
  arquivos): o usuário monta uma lista de compras (produto + marca +
  quantidade) e o sistema calcula (a) o estabelecimento único mais barato
  que tem todos os itens, e (b) a combinação mais barata dividindo a
  compra entre estabelecimentos, mostrando a economia. Usa
  `SantaBuscaStorage.getCatalogProducts()` (já existente) como fonte de
  dados — não precisou de tabela nova no banco. Link adicionado ao menu
  de navegação em `index.html`, `notificacoes.html`, `ranking.html` e
  `estabelecimento-publico.html`.
- Link para o handoff/QR/Cesta Ideal já testado com `node --check` em
  todos os `.js` (sintaxe válida) e contagem de tags `<section>`
  balanceada em todos os `.html` tocados — mas **sem teste real em
  navegador/MySQL**, porque o ambiente de execução não tem acesso à
  internet nem ao MySQL do usuário.

- **Termômetro de preços**: nova função `SantaBuscaStorage.getPriceThermometer()`
  em `app-storage.js` — 100% client-side, sem tabela nova nem endpoint novo
  no `server.js` (usa o `historico_precos` que já chega pelo `bootstrap()`
  e fica em `KEYS.prices` no `localStorage`). Compara, por produto, o
  último preço registrado no mês atual vs. o último do mês anterior, e
  tira a média das variações percentuais (só conta produtos com registro
  nos dois meses). Renderizado em `index.html` via
  `renderPriceThermometer()` em `script.js` (card `#price-thermometer`,
  classe CSS `.thermometerCard`).

## O que falta implementar

### 1. Prioridade por engajamento no ranking/busca
**Ideia**: hoje o ranking de estabelecimentos (`getEstablishmentRanking()`
em `app-storage.js`) é baseado só em denúncias (penalização). Adicionar um
fator de bônus para quem mantém catálogo completo e preços atualizados,
para aparecer melhor posicionado nas buscas/listagens.

**Cuidado**: essa é a mudança mais arriscada de todas porque mexe direto
na lógica de ranking que o dono do projeto já definiu como regra de
negócio fixa (reputação por denúncias). Antes de implementar, é melhor
CONFIRMAR com o usuário se ele quer um ranking novo específico (ex:
"Destaques da semana") ao invés de alterar o ranking oficial de
reputação — para não misturar dois conceitos (reputação por confiança vs.
prioridade por engajamento).

### 2. OCR de cupom fiscal (atualização de preço por foto)
**Ideia**: usuário tira foto do cupom fiscal e o app extrai
produtos/preços automaticamente, evitando digitação manual.

**Como fazer sem custo/API paga**: usar `Tesseract.js` (OCR 100%
client-side, via CDN, sem chave de API) para extrair o texto bruto da
imagem. Depois, escrever um parser heurístico (regex) que procura padrões
tipo `NOME DO PRODUTO ... 12,90` linha a linha. **Aviso importante**:
isso é o item de maior risco/incerteza tecnicamente — cupons fiscais
brasileiros têm formatos MUITO variados entre estabelecimentos, então a
extração nunca vai ser 100% confiável. Recomendo implementar como
"rascunho automático": o OCR preenche os campos, mas o usuário sempre
revisa e confirma antes de salvar (nunca salvar direto sem revisão
humana). Não tente prometer 100% de acerto para o usuário.

## Arquivos do projeto (referência rápida)
- `server.js` — back-end Node/MySQL
- `app-storage.js` — camada de dados (localStorage + lógica de negócio),
  usada por TODAS as páginas
- `api-client.js` — ponte entre `app-storage.js` e `server.js`
- `script.js` + `index.html` — página principal de busca/comparação
- `dashboard-estabelecimento.js` + `.html` — painel do lojista
- `estabelecimento.js` + `.html` — login/cadastro de lojista
- `estabelecimento-publico.html` — página pública do estabelecimento
- `ranking.html`, `notificacoes.html`, `cesta-ideal.html` — páginas do usuário
- `db.sql` — schema único e completo do banco `santa_busca` (não existe mais
  arquivo de migração separado; era redundante, pois `db.sql` já inclui
  todas as tabelas, inclusive as do Radar)
