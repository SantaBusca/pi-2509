"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const mysql = require("mysql2/promise");

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const DB = {
    host: process.env.DB_HOST || "127.0.0.1",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "santa_busca"
};

let pool;

function json(res, status, data) {
    res.writeHead(status, {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
        "Access-Control-Allow-Origin": "*"
    });
    res.end(JSON.stringify(data));
}

function nowSql() {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function sqlDate(value) {
    if (!value) return nowSql();
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return nowSql();
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function monthKey(value) {
    const d = value ? new Date(value) : new Date();
    if (Number.isNaN(d.getTime())) return monthKey();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function validCnpj(value) {
    const digits = String(value || "").replace(/\D/g, "");
    if (digits.length !== 14 || /^(\d)\1{13}$/.test(digits)) return false;
    const calc = (base) => {
        let factor = base.length - 7;
        let sum = 0;
        for (const char of base) {
            sum += Number(char) * factor;
            factor -= 1;
            if (factor < 2) factor = 9;
        }
        const rest = sum % 11;
        return rest < 2 ? 0 : 11 - rest;
    };
    return calc(digits.slice(0, 12)) === Number(digits[12]) &&
        calc(digits.slice(0, 13)) === Number(digits[13]);
}

function normalizeCnpj(value) {
    const digits = String(value || "").replace(/\D/g, "");
    return digits.length === 14
        ? digits.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5")
        : String(value || "");
}

function hashPassword(password) {
    return new Promise((resolve, reject) => {
        const salt = crypto.randomBytes(16).toString("hex");
        crypto.scrypt(String(password), salt, 64, (err, derived) => {
            if (err) return reject(err);
            resolve(`scrypt$${salt}$${derived.toString("hex")}`);
        });
    });
}

function verifyPassword(password, stored) {
    if (!stored) return false;
    const parts = String(stored).split("$");
    if (parts.length !== 3 || parts[0] !== "scrypt") return false;
    const [, salt, hex] = parts;
    const expected = Buffer.from(hex, "hex");
    return new Promise((resolve, reject) => {
        crypto.scrypt(String(password), salt, expected.length, (err, derived) => {
            if (err) return reject(err);
            resolve(expected.length === derived.length && crypto.timingSafeEqual(expected, derived));
        });
    });
}

async function readBody(req) {
    let raw = "";
    for await (const chunk of req) {
        raw += chunk;
        if (raw.length > 15 * 1024 * 1024) throw new Error("Payload muito grande.");
    }
    try { return raw ? JSON.parse(raw) : {}; } catch { return {}; }
}

function mapEst(row) {
    if (!row) return null;
    const e = { ...row };
    try { e.dias = JSON.parse(e.dias || "[]"); } catch { e.dias = []; }
    delete e.senha_hash;
    return e;
}

async function upsertEst(e, preservePassword = true) {
    const senhaHash = e.senha_hash || (e.senha ? await hashPassword(e.senha) : null);
    const sql = `INSERT INTO estabelecimentos
        (id,nome,email,senha_hash,cnpj,endereco,coordenadas,tipo,abertura,fechamento,dias,logo,foto,criado_em,atualizado_em)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
        nome=VALUES(nome), email=VALUES(email),
        senha_hash=${preservePassword ? "COALESCE(VALUES(senha_hash),senha_hash)" : "VALUES(senha_hash)"},
        cnpj=VALUES(cnpj), endereco=VALUES(endereco), coordenadas=VALUES(coordenadas), tipo=VALUES(tipo),
        abertura=VALUES(abertura), fechamento=VALUES(fechamento), dias=VALUES(dias), logo=VALUES(logo), foto=VALUES(foto), atualizado_em=VALUES(atualizado_em)`;
    await pool.execute(sql, [
        e.id, e.nome, String(e.email || "").toLowerCase(), senhaHash,
        normalizeCnpj(e.cnpj), e.endereco, e.coordenadas, e.tipo,
        e.abertura, e.fechamento,
        Array.isArray(e.dias) ? JSON.stringify(e.dias) : String(e.dias || ""),
        e.logo || null, e.foto || null,
        sqlDate(e.criado_em || e.criadoEm), sqlDate(e.atualizado_em || e.atualizadoEm)
    ]);
}

async function bootstrap() {
    const [estRows] = await pool.query("SELECT * FROM estabelecimentos ORDER BY nome");
    const [prod] = await pool.query("SELECT id,estabelecimento_id AS estabelecimentoId,nome,marca,categoria,unidade,preco,emoji,disponibilidade,origem_catalogo AS origemCatalogo,chave,criado_em AS criadoEm,atualizado_em AS atualizadoEm FROM produtos");
    const [off] = await pool.query("SELECT o.id,o.chave,o.estabelecimento_id AS criadaPor,o.produto,o.marca,o.preco,o.inicio,o.fim,o.criado_em AS criadoEm,o.atualizado_em AS atualizadoEm,e.nome AS estabelecimento FROM ofertas o JOIN estabelecimentos e ON e.id=o.estabelecimento_id");
    const [reports] = await pool.query("SELECT id,usuario,chave,produto,marca,estabelecimento,preco_atual AS precoAtual,novo_preco AS novoPreco,comprovante,status,data_registro AS data,mes FROM denuncias ORDER BY data_registro");
    const [points] = await pool.query("SELECT id,usuario,mes,quantidade,motivo,tipo,data_registro AS data FROM pontos_eventos ORDER BY data_registro");
    const [actions] = await pool.query("SELECT usuario,chave,acao,mes,data_registro AS data FROM acoes_usuario ORDER BY data_registro");
    const [removed] = await pool.query("SELECT estabelecimento_id AS estabelecimentoId,chave AS `key` FROM produtos_removidos");
    const [histRows] = await pool.query("SELECT chave,preco,data_registro AS data,origem FROM historico_precos ORDER BY id");
    const [priceAlerts] = await pool.query("SELECT id,usuario,chave,produto,marca,estabelecimento,preco_alvo AS precoAlvo,ativo,criado_em AS criadoEm,atualizado_em AS atualizadoEm FROM alertas_preco");
    const [searches] = await pool.query("SELECT id,usuario,consulta,consulta_normalizada AS consultaNormalizada,mes,data_registro AS data FROM buscas ORDER BY id");
    const [priceNotifications] = await pool.query("SELECT id,usuario,produto,marca,estabelecimento,preco,preco_alvo AS precoAlvo,tipo,data_registro AS data FROM notificacoes_preco ORDER BY data_registro DESC");
    const [establishmentViews] = await pool.query("SELECT id,estabelecimento_id AS estabelecimentoId,sessao,mes,data_registro AS data FROM visualizacoes_estabelecimentos ORDER BY id");
    const prices = {};
    for (const h of histRows) {
        if (!prices[h.chave]) prices[h.chave] = { unidade: "unidade", atualizadoEm: h.data, historico: [], confirmacoes: 0, denuncias: 0, notaEventos: [] };
        prices[h.chave].historico.push({ preco: Number(h.preco), data: h.data, origem: h.origem });
        prices[h.chave].atualizadoEm = h.data;
    }
    const [counts] = await pool.query("SELECT chave, COUNT(*) c FROM denuncias GROUP BY chave");
    for (const r of counts) if (prices[r.chave]) prices[r.chave].denuncias = Number(r.c);
    const [confirmations] = await pool.query('SELECT chave, COUNT(*) c FROM acoes_usuario WHERE acao="confirmar" GROUP BY chave');
    for (const r of confirmations) if (prices[r.chave]) prices[r.chave].confirmacoes = Number(r.c);
    return {
        ok: true,
        establishments: estRows.map(mapEst), products: prod, offers: off, reports,
        points: { events: points }, actions, removedProducts: removed, prices, priceAlerts, priceNotifications, searches, establishmentViews
    };
}

async function syncState(d) {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();
        for (const e of (d.establishments || [])) await upsertEst(e);
        for (const p of (d.products || [])) {
            await conn.execute(`INSERT INTO produtos (id,estabelecimento_id,nome,marca,categoria,unidade,preco,emoji,disponibilidade,origem_catalogo,chave,criado_em,atualizado_em)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE nome=VALUES(nome),marca=VALUES(marca),categoria=VALUES(categoria),unidade=VALUES(unidade),preco=VALUES(preco),emoji=VALUES(emoji),disponibilidade=VALUES(disponibilidade),chave=VALUES(chave),atualizado_em=VALUES(atualizado_em)`,
                [p.id,p.estabelecimentoId,p.nome,p.marca,p.categoria,p.unidade||"unidade",Number(p.preco)||0,p.emoji||null,p.disponibilidade||"disponivel",p.origemCatalogo?1:0,p.chave||"",sqlDate(p.criadoEm),sqlDate(p.atualizadoEm)]);
        }
        for (const o of (d.offers || [])) {
            await conn.execute(`INSERT INTO ofertas (id,chave,estabelecimento_id,produto,marca,preco,inicio,fim,criado_em,atualizado_em)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE produto=VALUES(produto),marca=VALUES(marca),preco=VALUES(preco),inicio=VALUES(inicio),fim=VALUES(fim),atualizado_em=VALUES(atualizado_em)`,
                [o.id,o.chave,o.criadaPor,o.produto,o.marca,Number(o.preco)||0,o.inicio?sqlDate(o.inicio):null,o.fim?sqlDate(o.fim):null,sqlDate(o.criadoEm),sqlDate(o.atualizadoEm)]);
        }
        for (const r of (d.reports || [])) {
            await conn.execute(`INSERT IGNORE INTO denuncias (id,usuario,chave,produto,marca,estabelecimento,preco_atual,novo_preco,comprovante,status,data_registro,mes)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
                [r.id,r.usuario,r.chave,r.produto,r.marca,r.estabelecimento,Number(r.precoAtual)||0,Number(r.novoPreco)||0,r.comprovante||null,r.status||"REGISTRADO",sqlDate(r.data),r.mes||monthKey(r.data)]);
        }
        for (const p of ((d.points && d.points.events) || [])) {
            await conn.execute(`INSERT IGNORE INTO pontos_eventos (id,usuario,mes,quantidade,motivo,tipo,data_registro) VALUES (?,?,?,?,?,?,?)`,
                [p.id,p.usuario,p.mes,Number(p.quantidade)||0,p.motivo,p.tipo,sqlDate(p.data)]);
        }
        for (const a of (d.actions || [])) {
            await conn.execute(`INSERT IGNORE INTO acoes_usuario (usuario,chave,acao,mes,data_registro) VALUES (?,?,?,?,?)`,
                [a.usuario,a.chave,a.acao,a.mes,sqlDate(a.data)]);
        }
        for (const r of (d.removedProducts || [])) {
            await conn.execute(`INSERT IGNORE INTO produtos_removidos (estabelecimento_id,chave) VALUES (?,?)`, [r.estabelecimentoId,r.key]);
        }
        for (const b of (d.searches || [])) {
            await conn.execute(`INSERT IGNORE INTO buscas (id,usuario,consulta,consulta_normalizada,mes,data_registro) VALUES (?,?,?,?,?,?)`,
                [b.id || `search-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,b.usuario || null,b.consulta,b.consultaNormalizada || String(b.consulta || "").trim().toLocaleLowerCase("pt-BR"),b.mes || monthKey(b.data),sqlDate(b.data)]);
        }
        for (const v of (d.establishmentViews || [])) {
            await conn.execute(`INSERT IGNORE INTO visualizacoes_estabelecimentos (id,estabelecimento_id,sessao,mes,data_registro) VALUES (?,?,?,?,?)`,
                [v.id || `view-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,v.estabelecimentoId,v.sessao || null,v.mes || monthKey(v.data),sqlDate(v.data)]);
        }
        for (const n of (d.priceNotifications || [])) {
            await conn.execute(`INSERT IGNORE INTO notificacoes_preco (id,usuario,produto,marca,estabelecimento,preco,preco_alvo,tipo,data_registro) VALUES (?,?,?,?,?,?,?,?,?)`,
                [n.id,n.usuario,n.produto,n.marca,n.estabelecimento,Number(n.preco)||0,Number(n.precoAlvo)||0,n.tipo||"preco_baixou",sqlDate(n.data)]);
        }
        for (const a of (d.priceAlerts || [])) {
            // A regra de 26+ pontos também é validada no servidor antes de gravar.
            const [pts] = await conn.execute("SELECT COALESCE(SUM(quantidade),0) AS total FROM pontos_eventos WHERE usuario=? AND mes=?", [a.usuario, monthKey(a.criadoEm)]);
            if (Number(pts[0]?.total || 0) <= 25) continue;
            await conn.execute(`INSERT INTO alertas_preco (id,usuario,chave,produto,marca,estabelecimento,preco_alvo,ativo,criado_em,atualizado_em) VALUES (?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE preco_alvo=VALUES(preco_alvo),ativo=VALUES(ativo),atualizado_em=VALUES(atualizado_em)`, [a.id,a.usuario,a.chave,a.produto,a.marca,a.estabelecimento,Number(a.precoAlvo)||0,a.ativo?1:0,sqlDate(a.criadoEm),sqlDate(a.atualizadoEm)]);
        }
        for (const [key, m] of Object.entries(d.prices || {})) {
            for (const h of (m.historico || [])) {
                // A tabela atual não possui uma chave natural do evento; evita duplicar exatamente o mesmo registro.
                const [exists] = await conn.execute("SELECT id FROM historico_precos WHERE chave=? AND preco=? AND data_registro=? AND origem=? LIMIT 1", [key,Number(h.preco)||0,sqlDate(h.data),h.origem||"registro"]);
                if (!exists.length) await conn.execute("INSERT INTO historico_precos (chave,preco,data_registro,origem) VALUES (?,?,?,?)", [key,Number(h.preco)||0,sqlDate(h.data),h.origem||"registro"]);
            }
        }
        await conn.commit();
    } catch (error) {
        await conn.rollback();
        throw error;
    } finally {
        conn.release();
    }
}

async function handleApi(req, res, url) {
    if (req.method === "OPTIONS") {
        res.writeHead(204, { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" });
        return res.end();
    }
    const action = url.searchParams.get("action") || "";
    try {
        if (req.method === "GET" && action === "health") return json(res, 200, { ok: true, database: "mysql", time: nowSql() });
        if (req.method === "GET" && action === "bootstrap") return json(res, 200, await bootstrap());

        const d = req.method === "POST" ? await readBody(req) : {};
        if (req.method === "POST" && action === "register") {
            // O ID é gerado pelo servidor; o formulário não precisa pedir esse campo.
            for (const k of ["nome","email","cnpj","endereco","coordenadas","tipo","abertura","fechamento","dias"]) {
                if (d[k] === undefined || d[k] === null || d[k] === "") return json(res, 422, { ok:false, error:`Campo obrigatório: ${k}` });
            }
            if (!d.id) {
                d.id = `est-${Date.now().toString(36)}-${crypto.randomBytes(4).toString("hex")}`;
            }
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) return json(res,422,{ok:false,error:"Email inválido."});
            const cnpj = normalizeCnpj(d.cnpj);
            if (!/^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(cnpj) || !validCnpj(cnpj)) return json(res,422,{ok:false,error:"CNPJ inválido."});
            const [found] = await pool.execute("SELECT id FROM estabelecimentos WHERE email=? OR cnpj=? LIMIT 1", [String(d.email).toLowerCase(),cnpj]);
            if (found.length) return json(res,409,{ok:false,error:"Email ou CNPJ já cadastrado."});
            if (!d.senha) return json(res,422,{ok:false,error:"Senha obrigatória."});
            d.cnpj = cnpj;
            d.senha_hash = await hashPassword(d.senha);
            await upsertEst(d, false);
            delete d.senha; delete d.senha_hash;
            return json(res,200,{ok:true,establishment:d});
        }

        if (req.method === "POST" && action === "login") {
            const [rows] = await pool.execute("SELECT * FROM estabelecimentos WHERE email=? LIMIT 1", [String(d.email || "").trim().toLowerCase()]);
            if (!rows.length) return json(res,401,{ok:false,error:"Email ou senha incorretos."});
            const e = rows[0];
            const valid = await verifyPassword(d.senha || "", e.senha_hash);
            if (!valid) return json(res,401,{ok:false,error:"Email ou senha incorretos."});
            return json(res,200,{ok:true,establishment:mapEst(e)});
        }

        if (req.method === "POST" && action === "sync") {
            await syncState(d);
            return json(res,200,{ok:true,syncedAt:nowSql()});
        }
        return json(res,404,{ok:false,error:"Ação não encontrada."});
    } catch (error) {
        console.error(error);
        return json(res,500,{ok:false,error:"Erro no servidor do Santa Busca.",detail:process.env.NODE_ENV === "production" ? undefined : error.message});
    }
}

const mime = {
    ".html":"text/html; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".css":"text/css; charset=utf-8",
    ".json":"application/json; charset=utf-8", ".png":"image/png", ".jpg":"image/jpeg", ".jpeg":"image/jpeg",
    ".svg":"image/svg+xml", ".ico":"image/x-icon", ".webp":"image/webp"
};

function serveStatic(req, res, url) {
    let pathname = decodeURIComponent(url.pathname);
    if (pathname === "/") pathname = "/index.html";
    const file = path.normalize(path.join(ROOT, pathname));
    if (!file.startsWith(ROOT)) return json(res,403,{error:"Acesso negado."});
    fs.stat(file, (err, stat) => {
        if (!err && stat.isFile()) {
            res.writeHead(200, { "Content-Type": mime[path.extname(file).toLowerCase()] || "application/octet-stream" });
            return fs.createReadStream(file).pipe(res);
        }
        json(res,404,{error:"Arquivo não encontrado."});
    });
}

async function start() {
    pool = mysql.createPool({ ...DB, waitForConnections:true, connectionLimit:10, charset:"utf8mb4" });
    await pool.query("SELECT 1");
    const server = http.createServer(async (req,res) => {
        const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
        if (url.pathname === "/api/api" || url.pathname === "/api/api/") return handleApi(req,res,url);
        serveStatic(req,res,url);
    });
    server.listen(PORT, () => {
        console.log(`Santa Busca rodando em http://localhost:${PORT}`);
        console.log(`MySQL: ${DB.user}@${DB.host}:${DB.port}/${DB.database}`);
    });
}

start().catch((error) => {
    console.error("Não foi possível iniciar o Santa Busca.");
    console.error(error.message);
    process.exit(1);
});
