/* Santa Busca — ponte entre o front-end e o MySQL via Node.js. */
(function () {
    "use strict";

    const API_URL = "/api/api";
    let timer = null;
    let syncing = false;

    function enabled() {
        return location.protocol === "http:" || location.protocol === "https:";
    }

    async function request(action, options = {}) {
        const response = await fetch(`${API_URL}?action=${encodeURIComponent(action)}`, {
            ...options,
            headers: {
                "Content-Type": "application/json",
                ...(options.headers || {})
            }
        });

        const data = await response.json();
        if (!response.ok || data.ok === false) {
            throw new Error(data.error || "Erro na API do Santa Busca.");
        }
        return data;
    }

    function statePayload() {
        const S = window.SantaBuscaStorage;
        return {
            establishments: S.getEstablishments(),
            products: S.read(S.KEYS.products, []),
            offers: Object.values(S.read(S.KEYS.offers, {})),
            reports: S.read(S.KEYS.reports, []),
            points: S.read(S.KEYS.points, { events: [] }),
            actions: S.read(S.KEYS.actions, []),
            removedProducts: S.read(S.KEYS.removedProducts, []),
            prices: S.read(S.KEYS.prices, {}),
            priceAlerts: S.read(S.KEYS.priceAlerts, []),
            priceNotifications: S.read(S.KEYS.priceNotifications, []),
            searches: S.read(S.KEYS.searches, []),
            establishmentViews: S.read(S.KEYS.establishmentViews, [])
        };
    }

    async function syncNow() {
        if (!enabled() || !window.SantaBuscaStorage || syncing) {
            return false;
        }
        syncing = true;
        try {
            await request("sync", {
                method: "POST",
                body: JSON.stringify(statePayload())
            });
            return true;
        } catch (error) {
            console.warn("Santa Busca: MySQL indisponível; mantendo persistência local.", error);
            return false;
        } finally {
            syncing = false;
        }
    }

    function queueSync() {
        if (!enabled()) return;
        clearTimeout(timer);
        timer = setTimeout(syncNow, 450);
    }

    async function hydrate() {
        if (!enabled() || !window.SantaBuscaStorage) return;
        // "ok" indica se conseguimos realmente falar com o servidor/MySQL.
        // Isso é usado pelas páginas (ex.: estabelecimento-publico.html) para
        // diferenciar "o servidor caiu, ainda não sabemos" de "o servidor
        // respondeu e confirmou que esse registro não existe".
        let ok = false;
        try {
            const data = await request("bootstrap");
            const S = window.SantaBuscaStorage;
            const hasServerData =
                data.establishments?.length ||
                data.products?.length ||
                data.reports?.length ||
                data.points?.events?.length ||
                data.searches?.length ||
                data.establishmentViews?.length ||
                Object.keys(data.prices || {}).length;

            if (hasServerData) {
                S.write(S.KEYS.establishments, data.establishments || []);
                S.write(S.KEYS.products, data.products || []);
                S.write(S.KEYS.offers, Object.fromEntries((data.offers || []).map((item) => [item.chave, item])));
                S.write(S.KEYS.reports, data.reports || []);
                S.write(S.KEYS.points, data.points || { events: [] });
                S.write(S.KEYS.actions, data.actions || []);
                S.write(S.KEYS.removedProducts, data.removedProducts || []);
                S.write(S.KEYS.prices, data.prices || {});
                S.write(S.KEYS.priceAlerts, data.priceAlerts || []);
                S.write(S.KEYS.priceNotifications, data.priceNotifications || []);
                S.write(S.KEYS.searches, data.searches || []);
                S.write(S.KEYS.establishmentViews, data.establishmentViews || []);
            } else {
                await syncNow();
            }
            ok = true;
        } catch (error) {
            console.warn("Santa Busca: API MySQL não configurada ou indisponível.", error);
        }
        document.dispatchEvent(new CustomEvent("santaBusca:serverReady", { detail: { ok } }));
    }

    function wrapMutators() {
        const S = window.SantaBuscaStorage;
        if (!S || S.__mysqlWrapped) return;
        S.__mysqlWrapped = true;

        [
            "write",
            "addPoint",
            "registerNoteAction",
            "reportPrice",
            "saveProduct",
            "deleteProduct",
            "saveEstablishment",
            "saveOffer",
            "deleteOffer",
            "updatePrice",
            "updateProductPrice",
            "recordSearch",
            "recordEstablishmentView",
            "addPriceAlert"
        ].forEach((name) => {
            if (typeof S[name] !== "function") return;
            const original = S[name];
            S[name] = function (...args) {
                const result = original.apply(this, args);
                queueSync();
                return result;
            };
        });
    }

    async function login(email, senha) {
        return request("login", {
            method: "POST",
            body: JSON.stringify({ email, senha })
        });
    }

    async function register(establishment) {
        return request("register", {
            method: "POST",
            body: JSON.stringify(establishment)
        });
    }

    window.SantaBuscaAPI = {
        url: API_URL,
        request,
        syncNow,
        queueSync,
        hydrate,
        enabled,
        login,
        register
    };

    wrapMutators();
    hydrate();
})();
