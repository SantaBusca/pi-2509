(function () {
    "use strict";

    const S = SantaBuscaStorage;
    const CART_KEY = "santaBusca:cestaIdeal";

    const $ = (id) => document.getElementById(id);

    function escapeHTML(value) {
        return String(value ?? "").replace(
            /[&<>"']/g,
            (character) => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[character])
        );
    }

    function formatPrice(value) {
        return `R$ ${Number(value || 0).toFixed(2).replace(".", ",")}`;
    }

    function getCatalog() {
        const base = (typeof DADOS_EMBUTIDOS !== "undefined" ? DADOS_EMBUTIDOS.produtos : []) || [];
        return S.getCatalogProducts(base);
    }

    function getCart() {
        return S.read(CART_KEY, []);
    }

    function saveCart(cart) {
        S.write(CART_KEY, cart);
    }

    function buildSuggestions(catalog) {
        const list = $("cesta-sugestoes");
        const options = [];

        catalog.forEach((product) => {
            (product.itens || []).forEach((item) => {
                if (!(item.mercados || []).some((m) => m.disponibilidade !== "esgotado")) {
                    return;
                }

                options.push({
                    nome: product.nome,
                    marca: item.marca,
                    label: `${product.nome} — ${item.marca}`
                });
            });
        });

        list.innerHTML = options
            .map((opt) => `<option value="${escapeHTML(opt.label)}"></option>`)
            .join("");

        return options;
    }

    function findOption(options, text) {
        const normalized = S.normalizeText(text);

        return options.find(
            (opt) => S.normalizeText(opt.label) === normalized
        ) || options.find((opt) =>
            S.normalizeText(`${opt.nome} ${opt.marca}`) === normalized
        );
    }

    function renderCart(cart) {
        const box = $("cesta-lista");

        if (!cart.length) {
            box.innerHTML = '<div class="mutedBox">Sua cesta está vazia. Adicione produtos acima.</div>';
            return;
        }

        box.innerHTML = cart
            .map((item, index) => `
                <article class="rankItem">
                    <div class="rankMain">
                        <strong>${escapeHTML(item.nome)}</strong>
                        <small>${escapeHTML(item.marca)} · Quantidade: ${item.qtd}</small>
                    </div>
                    <button class="miniAction dangerBtn" type="button" data-remove="${index}">Remover</button>
                </article>
            `)
            .join("");

        box.querySelectorAll("[data-remove]").forEach((button) => {
            button.addEventListener("click", () => {
                const idx = Number(button.getAttribute("data-remove"));
                const updated = getCart().filter((_, i) => i !== idx);
                saveCart(updated);
                renderCart(updated);
                $("cesta-resultado-section").style.display = "none";
            });
        });
    }

    function getStoreOptionsFor(catalog, nome, marca) {
        const product = catalog.find(
            (item) => S.normalizeText(item.nome) === S.normalizeText(nome)
        );

        const brand = (product?.itens || []).find(
            (item) => S.normalizeText(item.marca) === S.normalizeText(marca)
        );

        return (brand?.mercados || [])
            .filter((market) => market.disponibilidade !== "esgotado")
            .map((market) => {
                const key = S.priceKey(nome, marca, market.nome);
                const meta = S.ensurePriceMeta(key, market.preco);
                const normalPrice = S.currentNormalPrice(meta, market.preco);
                const price = Number(S.effectivePrice(key, normalPrice));

                return {
                    mercado: market.nome,
                    preco: price
                };
            })
            .filter((option) => Number.isFinite(option.preco));
    }

    function computeCesta(cart) {
        const catalog = getCatalog();

        const perItem = cart.map((entry) => ({
            ...entry,
            options: getStoreOptionsFor(catalog, entry.nome, entry.marca)
        }));

        const missing = perItem.filter((item) => !item.options.length);
        const available = perItem.filter((item) => item.options.length);

        const split = available.map((item) => {
            const best = item.options.reduce((a, b) => (b.preco < a.preco ? b : a));
            return { ...item, mercado: best.mercado, preco: best.preco };
        });

        const splitTotal = split.reduce(
            (sum, item) => sum + item.preco * item.qtd,
            0
        );

        const allStores = [...new Set(available.flatMap((item) => item.options.map((o) => o.mercado)))];

        const singleOptions = allStores
            .map((store) => {
                let total = 0;

                for (const item of available) {
                    const opt = item.options.find((o) => o.mercado === store);
                    if (!opt) {
                        return null;
                    }
                    total += opt.preco * item.qtd;
                }

                return { store, total };
            })
            .filter(Boolean)
            .sort((a, b) => a.total - b.total);

        const bestSingle = singleOptions[0] || null;
        const savings = bestSingle ? Math.max(0, bestSingle.total - splitTotal) : 0;

        return { split, splitTotal, bestSingle, missing };
    }

    function renderResult(result) {
        const section = $("cesta-resultado-section");
        const box = $("cesta-resultado");
        section.style.display = "block";

        const missingHTML = result.missing.length
            ? `<div class="mutedBox">Não encontramos preço disponível para: ${result.missing.map((m) => escapeHTML(m.nome)).join(", ")}.</div>`
            : "";

        if (!result.split.length) {
            box.innerHTML = `${missingHTML}<div class="mutedBox">Não foi possível calcular — nenhum item da cesta tem preço disponível.</div>`;
            return;
        }

        const splitRows = result.split
            .map((item) => `
                <article class="rankItem">
                    <div class="rankMain">
                        <strong>${escapeHTML(item.nome)} · ${escapeHTML(item.marca)}</strong>
                        <small>Comprar em: ${escapeHTML(item.mercado)} · Qtd: ${item.qtd}</small>
                    </div>
                    <b>${formatPrice(item.preco * item.qtd)}</b>
                </article>
            `)
            .join("");

        const singleHTML = result.bestSingle
            ? `
                <div class="cestaResumoCard">
                    <span class="eyebrow">TUDO NUM SÓ LUGAR</span>
                    <strong>${escapeHTML(result.bestSingle.store)}</strong>
                    <b>${formatPrice(result.bestSingle.total)}</b>
                </div>
            `
            : `<div class="cestaResumoCard"><span class="eyebrow">TUDO NUM SÓ LUGAR</span><small>Nenhum estabelecimento tem todos os itens da sua cesta.</small></div>`;

        const savingsHTML = result.bestSingle && result.savings > 0.009
            ? `<div class="cestaEconomia">💰 Dividindo a compra, você economiza <strong>${formatPrice(result.savings)}</strong> em relação a comprar tudo em ${escapeHTML(result.bestSingle.store)}.</div>`
            : "";

        box.innerHTML = `
            ${missingHTML}
            <div class="cestaComparacao">
                ${singleHTML}
                <div class="cestaResumoCard cestaResumoDestaque">
                    <span class="eyebrow">DIVIDINDO A COMPRA</span>
                    <strong>Melhor combinação</strong>
                    <b>${formatPrice(result.splitTotal)}</b>
                </div>
            </div>
            ${savingsHTML}
            <div class="subHeading" style="margin-top:18px"><div><h3>Onde comprar cada item</h3></div></div>
            <div class="radarList">${splitRows}</div>
        `;
    }

    function init() {
        const catalog = getCatalog();
        const options = buildSuggestions(catalog);
        let cart = getCart();
        renderCart(cart);

        $("cesta-add").addEventListener("click", () => {
            const text = $("cesta-produto").value.trim();
            const qtd = Math.max(1, Number($("cesta-qtd").value) || 1);
            const alert = $("cesta-add-alert");

            if (!text) {
                alert.textContent = "Escolha um produto da lista.";
                alert.classList.add("visible");
                return;
            }

            const match = findOption(options, text);

            if (!match) {
                alert.textContent = "Não encontramos esse produto/marca na nossa base. Selecione uma opção da lista.";
                alert.classList.add("visible");
                return;
            }

            alert.classList.remove("visible");
            cart = getCart();
            cart.push({ nome: match.nome, marca: match.marca, qtd });
            saveCart(cart);
            renderCart(cart);
            $("cesta-produto").value = "";
            $("cesta-qtd").value = "1";
            $("cesta-resultado-section").style.display = "none";
        });

        $("cesta-calcular").addEventListener("click", () => {
            cart = getCart();

            if (!cart.length) {
                return;
            }

            const result = computeCesta(cart);
            renderResult(result);
        });
    }

    document.addEventListener("santaBusca:serverReady", () => {
        // Recalcula sugestões caso os dados do servidor cheguem depois do carregamento inicial.
        buildSuggestions(getCatalog());
    });

    init();
})();
